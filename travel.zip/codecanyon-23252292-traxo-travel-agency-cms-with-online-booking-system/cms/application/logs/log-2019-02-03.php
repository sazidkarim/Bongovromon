<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-03 00:08:10 --> 404 Page Not Found: Public/uploads
ERROR - 2019-02-03 00:08:10 --> 404 Page Not Found: Public/uploads
ERROR - 2019-02-03 00:30:17 --> 404 Page Not Found: Public/css
ERROR - 2019-02-03 00:32:03 --> 404 Page Not Found: Public/css
ERROR - 2019-02-03 00:33:24 --> 404 Page Not Found: Public/css
ERROR - 2019-02-03 00:33:56 --> 404 Page Not Found: Public/css
ERROR - 2019-02-03 00:34:16 --> 404 Page Not Found: Public/css
ERROR - 2019-02-03 07:05:39 --> Severity: Notice --> Undefined variable: data /home/demoslyc/public_html/traxo/application/controllers/admin/Destination.php 351
ERROR - 2019-02-03 07:05:39 --> Severity: Notice --> Undefined variable: destination /home/demoslyc/public_html/traxo/application/views/admin/view_destination_edit.php 38
ERROR - 2019-02-03 07:05:39 --> Severity: Notice --> Undefined variable: destination /home/demoslyc/public_html/traxo/application/views/admin/view_destination_edit.php 39
ERROR - 2019-02-03 07:05:39 --> Severity: Notice --> Undefined variable: destination /home/demoslyc/public_html/traxo/application/views/admin/view_destination_edit.php 40
ERROR - 2019-02-03 07:05:39 --> Severity: Notice --> Undefined variable: destination /home/demoslyc/public_html/traxo/application/views/admin/view_destination_edit.php 46
ERROR - 2019-02-03 07:05:39 --> Severity: Notice --> Undefined variable: destination /home/demoslyc/public_html/traxo/application/views/admin/view_destination_edit.php 52
ERROR - 2019-02-03 07:05:39 --> Severity: Notice --> Undefined variable: destination /home/demoslyc/public_html/traxo/application/views/admin/view_destination_edit.php 58
ERROR - 2019-02-03 07:05:39 --> Severity: Notice --> Undefined variable: destination /home/demoslyc/public_html/traxo/application/views/admin/view_destination_edit.php 64
ERROR - 2019-02-03 07:05:39 --> Severity: Notice --> Undefined variable: destination /home/demoslyc/public_html/traxo/application/views/admin/view_destination_edit.php 70
ERROR - 2019-02-03 07:05:39 --> Severity: Notice --> Undefined variable: destination /home/demoslyc/public_html/traxo/application/views/admin/view_destination_edit.php 76
ERROR - 2019-02-03 07:05:39 --> Severity: Notice --> Undefined variable: destination /home/demoslyc/public_html/traxo/application/views/admin/view_destination_edit.php 82
ERROR - 2019-02-03 07:05:39 --> Severity: Notice --> Undefined variable: destination /home/demoslyc/public_html/traxo/application/views/admin/view_destination_edit.php 88
ERROR - 2019-02-03 07:05:39 --> Severity: Notice --> Undefined variable: destination /home/demoslyc/public_html/traxo/application/views/admin/view_destination_edit.php 100
ERROR - 2019-02-03 07:05:39 --> Severity: Notice --> Undefined variable: destination /home/demoslyc/public_html/traxo/application/views/admin/view_destination_edit.php 112
ERROR - 2019-02-03 07:05:39 --> Severity: Notice --> Undefined variable: destination /home/demoslyc/public_html/traxo/application/views/admin/view_destination_edit.php 118
ERROR - 2019-02-03 07:05:39 --> Severity: Notice --> Undefined variable: destination /home/demoslyc/public_html/traxo/application/views/admin/view_destination_edit.php 124
ERROR - 2019-02-03 07:05:39 --> Severity: Notice --> Undefined variable: destination /home/demoslyc/public_html/traxo/application/views/admin/view_destination_edit.php 130
ERROR - 2019-02-03 07:05:39 --> Severity: Notice --> Undefined variable: destination /home/demoslyc/public_html/traxo/application/views/admin/view_destination_edit.php 136
ERROR - 2019-02-03 07:05:39 --> Severity: Notice --> Undefined variable: destination /home/demoslyc/public_html/traxo/application/views/admin/view_destination_edit.php 142
ERROR - 2019-02-03 07:05:39 --> Severity: Notice --> Undefined variable: destination /home/demoslyc/public_html/traxo/application/views/admin/view_destination_edit.php 151
ERROR - 2019-02-03 07:05:39 --> Severity: Notice --> Undefined variable: destination /home/demoslyc/public_html/traxo/application/views/admin/view_destination_edit.php 157
ERROR - 2019-02-03 07:05:39 --> Severity: Notice --> Undefined variable: destination /home/demoslyc/public_html/traxo/application/views/admin/view_destination_edit.php 163
ERROR - 2019-02-03 07:13:37 --> Severity: Notice --> Undefined variable: num_rows /home/demoslyc/public_html/traxo/application/models/admin/Model_destination.php 58
ERROR - 2019-02-03 07:16:21 --> Severity: Notice --> Undefined variable: num_rows /home/demoslyc/public_html/traxo/application/models/admin/Model_destination.php 58
ERROR - 2019-02-03 07:20:32 --> Severity: Compile Error --> Cannot redeclare Model_package::package_check() /home/demoslyc/public_html/traxo/application/models/admin/Model_package.php 130
ERROR - 2019-02-03 07:27:40 --> 404 Page Not Found: News/4
ERROR - 2019-02-03 07:27:42 --> 404 Page Not Found: News/4
ERROR - 2019-02-03 07:27:42 --> 404 Page Not Found: News/4
ERROR - 2019-02-03 07:30:32 --> 404 Page Not Found: News/3
ERROR - 2019-02-03 07:30:33 --> 404 Page Not Found: News/3
ERROR - 2019-02-03 07:30:34 --> 404 Page Not Found: News/3
ERROR - 2019-02-03 09:04:08 --> 404 Page Not Found: admin/Subscriber_email/index
ERROR - 2019-02-03 09:05:14 --> 404 Page Not Found: admin/Subscriber_email/index
ERROR - 2019-02-03 09:08:34 --> 404 Page Not Found: Public/admin
ERROR - 2019-02-03 09:08:34 --> 404 Page Not Found: Public/admin
ERROR - 2019-02-03 09:08:53 --> 404 Page Not Found: Public/admin
ERROR - 2019-02-03 09:08:54 --> 404 Page Not Found: Public/admin
ERROR - 2019-02-03 09:09:32 --> 404 Page Not Found: Public/admin
ERROR - 2019-02-03 09:09:32 --> 404 Page Not Found: Public/admin
ERROR - 2019-02-03 09:31:13 --> Severity: Warning --> Use of undefined constant BASE_URL - assumed 'BASE_URL' (this will throw an Error in a future version of PHP) /home/demoslyc/public_html/traxo/application/controllers/Newsletter.php 59
ERROR - 2019-02-03 09:31:13 --> Severity: Notice --> Undefined variable: to /home/demoslyc/public_html/traxo/application/controllers/Newsletter.php 59
ERROR - 2019-02-03 09:43:24 --> Severity: Notice --> Undefined variable: comment /home/demoslyc/public_html/traxo/application/views/view_header.php 210
ERROR - 2019-02-03 09:43:24 --> Severity: Notice --> Undefined variable: packages /home/demoslyc/public_html/traxo/application/views/view_footer.php 51
ERROR - 2019-02-03 09:43:24 --> Severity: Warning --> Invalid argument supplied for foreach() /home/demoslyc/public_html/traxo/application/views/view_footer.php 51
ERROR - 2019-02-03 09:43:24 --> Severity: Notice --> Undefined variable: featured_packages /home/demoslyc/public_html/traxo/application/views/view_footer.php 72
ERROR - 2019-02-03 09:43:24 --> Severity: Warning --> Invalid argument supplied for foreach() /home/demoslyc/public_html/traxo/application/views/view_footer.php 72
ERROR - 2019-02-03 09:43:24 --> Severity: Notice --> Undefined variable: all_news /home/demoslyc/public_html/traxo/application/views/view_footer.php 89
ERROR - 2019-02-03 09:43:24 --> Severity: Warning --> Invalid argument supplied for foreach() /home/demoslyc/public_html/traxo/application/views/view_footer.php 89
ERROR - 2019-02-03 09:43:24 --> Severity: Notice --> Undefined variable: social /home/demoslyc/public_html/traxo/application/views/view_footer.php 117
ERROR - 2019-02-03 09:43:24 --> Severity: Warning --> Invalid argument supplied for foreach() /home/demoslyc/public_html/traxo/application/views/view_footer.php 117
ERROR - 2019-02-03 10:24:51 --> 404 Page Not Found: Public/css
ERROR - 2019-02-03 10:36:43 --> 404 Page Not Found: Public/css
