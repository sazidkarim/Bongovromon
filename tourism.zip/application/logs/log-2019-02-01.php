<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-01 22:43:56 --> 404 Page Not Found: Public/uploads
ERROR - 2019-02-01 22:44:12 --> 404 Page Not Found: Public/images
ERROR - 2019-02-01 22:44:12 --> 404 Page Not Found: Public/images
ERROR - 2019-02-01 22:44:51 --> 404 Page Not Found: Public/images
ERROR - 2019-02-01 22:44:51 --> 404 Page Not Found: Public/images
ERROR - 2019-02-01 22:45:17 --> 404 Page Not Found: Public/images
ERROR - 2019-02-01 22:45:17 --> 404 Page Not Found: Public/images
ERROR - 2019-02-01 22:46:24 --> 404 Page Not Found: Public/images
ERROR - 2019-02-01 22:46:24 --> 404 Page Not Found: Public/images
