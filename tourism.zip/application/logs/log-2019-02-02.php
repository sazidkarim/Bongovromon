<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-02 09:36:01 --> 404 Page Not Found: Public/uploads
ERROR - 2019-02-02 11:24:18 --> 404 Page Not Found: Public/uploads
ERROR - 2019-02-02 11:24:18 --> 404 Page Not Found: Public/uploads
ERROR - 2019-02-02 11:28:39 --> 404 Page Not Found: Public/uploads
ERROR - 2019-02-02 11:28:39 --> 404 Page Not Found: Public/uploads
ERROR - 2019-02-02 11:29:51 --> Severity: Notice --> Undefined index: email_method /home/demoslyc/public_html/traxo/application/views/admin/view_setting.php 185
ERROR - 2019-02-02 11:29:51 --> Severity: Notice --> Undefined index: email_method /home/demoslyc/public_html/traxo/application/views/admin/view_setting.php 186
ERROR - 2019-02-02 11:29:51 --> Severity: Notice --> Undefined index: email_method /home/demoslyc/public_html/traxo/application/views/admin/view_setting.php 190
ERROR - 2019-02-02 11:29:51 --> Severity: Notice --> Undefined index: smtp_host /home/demoslyc/public_html/traxo/application/views/admin/view_setting.php 194
ERROR - 2019-02-02 11:29:51 --> Severity: Notice --> Undefined index: smtp_port /home/demoslyc/public_html/traxo/application/views/admin/view_setting.php 200
ERROR - 2019-02-02 11:29:51 --> Severity: Notice --> Undefined index: smtp_username /home/demoslyc/public_html/traxo/application/views/admin/view_setting.php 206
ERROR - 2019-02-02 11:29:51 --> Severity: Notice --> Undefined index: smtp_password /home/demoslyc/public_html/traxo/application/views/admin/view_setting.php 212
ERROR - 2019-02-02 11:36:51 --> Severity: Notice --> Undefined variable: data /home/demoslyc/public_html/traxo/application/controllers/Traveller.php 138
ERROR - 2019-02-02 11:39:19 --> 404 Page Not Found: Public/uploads
ERROR - 2019-02-02 12:52:33 --> Severity: Notice --> Undefined variable: data /home/demoslyc/public_html/traxo/application/controllers/Traveller.php 138
ERROR - 2019-02-02 12:59:01 --> Severity: Notice --> Undefined variable: data /home/demoslyc/public_html/traxo/application/controllers/Traveller.php 138
ERROR - 2019-02-02 12:59:01 --> Severity: Notice --> Undefined variable: data /home/demoslyc/public_html/traxo/application/controllers/Traveller.php 138
ERROR - 2019-02-02 13:00:50 --> Severity: Notice --> Undefined variable: data /home/demoslyc/public_html/traxo/application/controllers/Traveller.php 132
ERROR - 2019-02-02 13:00:50 --> Severity: Notice --> Undefined variable: data /home/demoslyc/public_html/traxo/application/controllers/Traveller.php 132
ERROR - 2019-02-02 13:15:30 --> 404 Page Not Found: Registration/verify
ERROR - 2019-02-02 13:15:37 --> 404 Page Not Found: Registration/verify
ERROR - 2019-02-02 13:17:46 --> 404 Page Not Found: Registration/verify
ERROR - 2019-02-02 13:20:48 --> 404 Page Not Found: Public/uploads
ERROR - 2019-02-02 13:24:00 --> Severity: Notice --> Undefined variable: tot /home/demoslyc/public_html/traxo/application/controllers/Traveller.php 115
ERROR - 2019-02-02 13:24:59 --> Severity: Notice --> Undefined variable: tot /home/demoslyc/public_html/traxo/application/controllers/Traveller.php 115
ERROR - 2019-02-02 13:30:27 --> 404 Page Not Found: Public/uploads
ERROR - 2019-02-02 13:30:28 --> 404 Page Not Found: Public/uploads
ERROR - 2019-02-02 14:51:41 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) /home/demoslyc/public_html/traxo/application/libraries/Common_lib.php 19
ERROR - 2019-02-02 14:51:43 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) /home/demoslyc/public_html/traxo/application/libraries/Common_lib.php 19
ERROR - 2019-02-02 14:51:44 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) /home/demoslyc/public_html/traxo/application/libraries/Common_lib.php 19
ERROR - 2019-02-02 14:53:03 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) /home/demoslyc/public_html/traxo/application/libraries/Common_lib.php 19
ERROR - 2019-02-02 14:56:13 --> Severity: error --> Exception: Cannot access parent:: when current class scope has no parent /home/demoslyc/public_html/traxo/application/libraries/Common_lib.php 8
ERROR - 2019-02-02 15:34:06 --> Severity: error --> Exception: Unable to locate the model you have specified: Model_header /home/demoslyc/public_html/traxo/system/core/Loader.php 348
ERROR - 2019-02-02 15:36:38 --> Severity: error --> Exception: Unable to locate the model you have specified: Model_header /home/demoslyc/public_html/traxo/system/core/Loader.php 348
ERROR - 2019-02-02 15:48:28 --> Severity: Notice --> Undefined variable: error /home/demoslyc/public_html/traxo/application/views/admin/view_profile.php 15
ERROR - 2019-02-02 15:48:28 --> Severity: Notice --> Undefined variable: success /home/demoslyc/public_html/traxo/application/views/admin/view_profile.php 21
ERROR - 2019-02-02 16:04:20 --> Query error: Unknown column 'full_name' in 'field list' - Invalid query: UPDATE `tbl_user` SET `full_name` = '', `email` = 'admin@gmail.com', `phone` = ''
WHERE `id` = 1
ERROR - 2019-02-02 16:19:41 --> 404 Page Not Found: Public/uploads
ERROR - 2019-02-02 16:19:41 --> 404 Page Not Found: Public/uploads
ERROR - 2019-02-02 16:31:38 --> Severity: Notice --> Undefined property: Package::$Model_payment /home/demoslyc/public_html/traxo/application/views/admin/view_package.php 62
ERROR - 2019-02-02 16:31:38 --> Severity: error --> Exception: Call to a member function get_total_persons_by_package() on null /home/demoslyc/public_html/traxo/application/views/admin/view_package.php 62
ERROR - 2019-02-02 16:32:07 --> Severity: Notice --> Undefined variable: id /home/demoslyc/public_html/traxo/application/models/Model_payment.php 40
ERROR - 2019-02-02 16:32:07 --> Severity: Notice --> Undefined variable: id /home/demoslyc/public_html/traxo/application/models/Model_payment.php 40
ERROR - 2019-02-02 16:32:07 --> Severity: Notice --> Undefined variable: id /home/demoslyc/public_html/traxo/application/models/Model_payment.php 40
ERROR - 2019-02-02 16:32:07 --> Severity: Notice --> Undefined variable: id /home/demoslyc/public_html/traxo/application/models/Model_payment.php 40
ERROR - 2019-02-02 16:32:07 --> Severity: Notice --> Undefined variable: id /home/demoslyc/public_html/traxo/application/models/Model_payment.php 40
ERROR - 2019-02-02 16:32:07 --> Severity: Notice --> Undefined variable: id /home/demoslyc/public_html/traxo/application/models/Model_payment.php 40
ERROR - 2019-02-02 16:32:07 --> Severity: Notice --> Undefined variable: id /home/demoslyc/public_html/traxo/application/models/Model_payment.php 40
ERROR - 2019-02-02 16:32:07 --> Severity: Notice --> Undefined variable: id /home/demoslyc/public_html/traxo/application/models/Model_payment.php 40
ERROR - 2019-02-02 16:32:07 --> Severity: Notice --> Undefined variable: id /home/demoslyc/public_html/traxo/application/models/Model_payment.php 40
ERROR - 2019-02-02 16:32:07 --> Severity: Notice --> Undefined variable: id /home/demoslyc/public_html/traxo/application/models/Model_payment.php 40
ERROR - 2019-02-02 16:32:07 --> Severity: Notice --> Undefined variable: id /home/demoslyc/public_html/traxo/application/models/Model_payment.php 40
ERROR - 2019-02-02 16:32:07 --> Severity: Notice --> Undefined variable: id /home/demoslyc/public_html/traxo/application/models/Model_payment.php 40
ERROR - 2019-02-02 16:32:07 --> Severity: Notice --> Undefined variable: id /home/demoslyc/public_html/traxo/application/models/Model_payment.php 40
ERROR - 2019-02-02 16:32:07 --> Severity: Notice --> Undefined variable: id /home/demoslyc/public_html/traxo/application/models/Model_payment.php 40
ERROR - 2019-02-02 16:32:07 --> Severity: Notice --> Undefined variable: id /home/demoslyc/public_html/traxo/application/models/Model_payment.php 40
ERROR - 2019-02-02 16:32:07 --> Severity: Notice --> Undefined variable: id /home/demoslyc/public_html/traxo/application/models/Model_payment.php 40
ERROR - 2019-02-02 16:32:07 --> Severity: Notice --> Undefined variable: id /home/demoslyc/public_html/traxo/application/models/Model_payment.php 40
ERROR - 2019-02-02 16:32:07 --> Severity: Notice --> Undefined variable: id /home/demoslyc/public_html/traxo/application/models/Model_payment.php 40
ERROR - 2019-02-02 16:32:07 --> Severity: Notice --> Undefined variable: id /home/demoslyc/public_html/traxo/application/models/Model_payment.php 40
ERROR - 2019-02-02 16:32:07 --> Severity: Notice --> Undefined variable: id /home/demoslyc/public_html/traxo/application/models/Model_payment.php 40
ERROR - 2019-02-02 16:32:07 --> Severity: Notice --> Undefined variable: id /home/demoslyc/public_html/traxo/application/models/Model_payment.php 40
ERROR - 2019-02-02 16:32:07 --> Severity: Notice --> Undefined variable: id /home/demoslyc/public_html/traxo/application/models/Model_payment.php 40
ERROR - 2019-02-02 16:32:07 --> Severity: Notice --> Undefined variable: id /home/demoslyc/public_html/traxo/application/models/Model_payment.php 40
ERROR - 2019-02-02 16:32:07 --> Severity: Notice --> Undefined variable: id /home/demoslyc/public_html/traxo/application/models/Model_payment.php 40
ERROR - 2019-02-02 16:32:07 --> Severity: Notice --> Undefined variable: id /home/demoslyc/public_html/traxo/application/models/Model_payment.php 40
ERROR - 2019-02-02 16:32:07 --> Severity: Notice --> Undefined variable: id /home/demoslyc/public_html/traxo/application/models/Model_payment.php 40
ERROR - 2019-02-02 16:32:07 --> Severity: Notice --> Undefined variable: id /home/demoslyc/public_html/traxo/application/models/Model_payment.php 40
ERROR - 2019-02-02 16:32:07 --> Severity: Notice --> Undefined variable: id /home/demoslyc/public_html/traxo/application/models/Model_payment.php 40
ERROR - 2019-02-02 16:32:07 --> Severity: Notice --> Undefined variable: id /home/demoslyc/public_html/traxo/application/models/Model_payment.php 40
ERROR - 2019-02-02 16:32:07 --> Severity: Notice --> Undefined variable: id /home/demoslyc/public_html/traxo/application/models/Model_payment.php 40
ERROR - 2019-02-02 16:32:07 --> Severity: Notice --> Undefined variable: id /home/demoslyc/public_html/traxo/application/models/Model_payment.php 40
ERROR - 2019-02-02 16:32:07 --> Severity: Notice --> Undefined variable: id /home/demoslyc/public_html/traxo/application/models/Model_payment.php 40
ERROR - 2019-02-02 16:32:07 --> Severity: Notice --> Undefined variable: id /home/demoslyc/public_html/traxo/application/models/Model_payment.php 40
ERROR - 2019-02-02 16:32:07 --> Severity: Notice --> Undefined variable: id /home/demoslyc/public_html/traxo/application/models/Model_payment.php 40
ERROR - 2019-02-02 16:32:07 --> Severity: Notice --> Undefined variable: id /home/demoslyc/public_html/traxo/application/models/Model_payment.php 40
ERROR - 2019-02-02 16:32:07 --> Severity: Notice --> Undefined variable: id /home/demoslyc/public_html/traxo/application/models/Model_payment.php 40
ERROR - 2019-02-02 16:53:32 --> 404 Page Not Found: Public/uploads
ERROR - 2019-02-02 16:53:32 --> 404 Page Not Found: Public/uploads
ERROR - 2019-02-02 20:36:43 --> 404 Page Not Found: Public/uploads
ERROR - 2019-02-02 20:36:44 --> 404 Page Not Found: Public/uploads
ERROR - 2019-02-02 20:53:24 --> 404 Page Not Found: Public/uploads
ERROR - 2019-02-02 20:53:24 --> 404 Page Not Found: Public/uploads
ERROR - 2019-02-02 20:56:44 --> 404 Page Not Found: Public/uploads
ERROR - 2019-02-02 21:36:43 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE), expecting ',' or ';' /home/demoslyc/public_html/traxo/application/views/view_package.php 52
ERROR - 2019-02-02 21:37:03 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) /home/demoslyc/public_html/traxo/application/views/view_package.php 52
ERROR - 2019-02-02 21:37:06 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) /home/demoslyc/public_html/traxo/application/views/view_package.php 52
ERROR - 2019-02-02 21:40:25 --> Severity: Notice --> Undefined property: paypal_lib::$Model_common /home/demoslyc/public_html/traxo/application/libraries/Paypal_lib.php 25
ERROR - 2019-02-02 21:40:25 --> Severity: error --> Exception: Call to a member function all_setting() on null /home/demoslyc/public_html/traxo/application/libraries/Paypal_lib.php 25
ERROR - 2019-02-02 21:41:50 --> Severity: Notice --> Undefined property: paypal_lib::$Model_common /home/demoslyc/public_html/traxo/application/libraries/Paypal_lib.php 25
ERROR - 2019-02-02 21:41:50 --> Severity: error --> Exception: Call to a member function all_setting() on null /home/demoslyc/public_html/traxo/application/libraries/Paypal_lib.php 25
ERROR - 2019-02-02 21:44:10 --> 404 Page Not Found: Public/images
ERROR - 2019-02-02 21:44:10 --> 404 Page Not Found: Public/images
